#include <stdlib.h>

int main() {
    system("ls -al /var/log/");
    return 0;
}
