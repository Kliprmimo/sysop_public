#!/bin/bash
./magick composite "$2" "$1" -geometry "+"$3"+"$4 dokument_podpisany.png
